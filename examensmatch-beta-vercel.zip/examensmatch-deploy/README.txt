Examensmatch Beta - statisk testversion

Publicering på Vercel:
- Projektrot: denna mapp
- Framework preset: Other
- Build command: lämna tom
- Output directory: lämna tom

index.html är startsidan.
